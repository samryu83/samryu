import { useEffect, useState } from 'react';
import { db } from '@/lib/firebase';
import { collection, addDoc, onSnapshot, serverTimestamp, query, orderBy } from 'firebase/firestore';

export default function ChatBox() {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<any[]>([]);

  const sendMessage = async () => {
    if (!message.trim()) return;
    await addDoc(collection(db, 'chat'), {
      content: message,
      createdAt: serverTimestamp(),
    });
    setMessage('');
  };

  useEffect(() => {
    const q = query(collection(db, 'chat'), orderBy('createdAt'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMessages(data);
    });
    return () => unsubscribe();
  }, []);

  return (
    <div className="p-4 border rounded-xl bg-white dark:bg-zinc-900">
      <div className="h-64 overflow-y-auto mb-4">
        {messages.map((m) => (
          <div key={m.id} className="text-sm py-1 border-b">{m.content}</div>
        ))}
      </div>
      <input
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        className="border p-2 rounded w-full mb-2"
        placeholder="메시지를 입력하세요"
      />
      <button onClick={sendMessage} className="bg-blue-500 text-white px-4 py-2 rounded">
        전송
      </button>
    </div>
  );
}
